﻿using Abc.Pharma.Shared.Entities;
using System.Data.Entity;

namespace Abc.Pharma.Repository
{
    public class MedicineContext : DbContext
    {
        public MedicineContext()
        {

        }
        public DbSet<Medicine> Medicines { get; set; }
        public DbSet<Orders> Orders { get; set; }
    }
}
