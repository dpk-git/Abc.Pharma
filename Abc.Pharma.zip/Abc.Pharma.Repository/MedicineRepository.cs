﻿using Abc.Pharma.Shared.Entities;
using Abc.Pharma.Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Abc.Pharma.Repository
{
    public class MedicineRepository : IMedicineRepository
    {
        MedicineContext _context;
        public MedicineRepository(MedicineContext context)
        {
            _context = context;
        }
        public void AddMedicine(Medicine medicine)
        {
            try
            {
                if (medicine != null)
                {
                    _context.Medicines.Add(medicine);
                    _context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error-MedicalRepository-AddMedicine:", ex.Message);
                throw;
            }

        }

        public bool NameExists(string name)
        {
            try
            {
                return GetMedicines().Any(x => x.Name == name);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error-MedicalRepository-NameExist:", ex.Message);
                throw;
            }
        }

        public IEnumerable<Medicine> GetMedicines()
        {
            try
            {
                return _context.Medicines;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error-MedicalRepository-GetMedicines:", ex.Message);
                throw;
            }
        }

        public Medicine GetMedicines(string id)
        {
            try
            {
                return _context.Medicines.FirstOrDefault(x => x.Id == id);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error-MedicalRepository-GetMedicines:", ex.Message);
                throw;
            }
        }

        public void Updatemedicine(Medicine medicine)
        {
            try
            {
                var med = _context.Medicines.First(x => x.Id == medicine.Id);
                med.Brand = medicine.Brand;
                med.ExpiryDate = medicine.ExpiryDate;
                med.Notes = medicine.Notes;
                med.Price = medicine.Price;
                med.Quantity = medicine.Quantity;
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error-MedicalRepository-UpdateMedicine:", ex.Message);
                throw;
            }
        }
    }
}
