﻿using Abc.Pharma.Shared.Entities;
using System.Collections.Generic;

namespace Abc.Pharma.Repository
{
    public interface IMedicineRepository
    {
        IEnumerable<Medicine> GetMedicines();
        void AddMedicine(Medicine medicine);
        bool NameExists(string name);
        Medicine GetMedicines(string id);
        void Updatemedicine(Medicine medicine);
    }
}
