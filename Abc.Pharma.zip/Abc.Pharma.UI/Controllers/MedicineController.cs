﻿using Abc.Pharma.Shared;
using Abc.Pharma.Shared.Entities;
using Abc.Pharma.Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Abc.Pharma.UI.Controllers
{
    public class MedicineController : Controller
    {
        string baseUrl = System.Configuration.ConfigurationManager.AppSettings["ApiBaseUrl"] + "/api/Medicines";
        public async Task<ActionResult> Index()
        {
            var result = await CustomHttpClient.GetAsync<IEnumerable<Medicine>>(new Uri(baseUrl));
            if (result.HasError)
                ViewBag.Error = result.Error;

            return View(result.Response);
        }



        [HttpGet]
        public ActionResult Add()
        {
            return View(new NewMedicineVM());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Add(NewMedicineVM newMedicine)
        {
            if (ModelState.IsValid)
            {
                var result = await CustomHttpClient.PostAsync<bool>(new Uri(baseUrl), newMedicine);
                if (result.HasError)
                    ViewBag.Error = result.Error;
                else if (result.Response == false)
                    ViewBag.Error = "Medicine couldn't be added";
                return RedirectToAction("Index");
            }

            return View(newMedicine);
        }

        [HttpGet]
        public async Task<ActionResult> Edit(string id)
        {
            var result = await CustomHttpClient.GetAsync<Medicine>(new Uri(baseUrl + "/" + id));
            if (result.HasError)
                ViewBag.Error = result.Error;

            var model = new NewMedicineVM
            {
                Brand = result.Response.Brand,
                Name = result.Response.Name,
                Price = result.Response.Price,
                ExpiryDate = string.Format("{0:dd/MM/yyyyy}", result.Response.ExpiryDate),
                Quantity = result.Response.Quantity,
                Notes = result.Response.Notes,
            };

            ViewBag.Id = id;
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(NewMedicineVM editedMedicine, string id)
        {
            if (ModelState.IsValid)
            {
                var result = await CustomHttpClient.PostAsync<bool>(new Uri(baseUrl + "/" + id), editedMedicine);
                if (result.HasError)
                    ViewBag.Error = result.Error;
                else if (result.Response == false)
                    ViewBag.Error = "Medicine couldn't be added";
                return RedirectToAction("Index");
            }

            return View(editedMedicine);
        }
    }
}
