﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Abc.Pharma.UI.Startup))]
namespace Abc.Pharma.UI
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
