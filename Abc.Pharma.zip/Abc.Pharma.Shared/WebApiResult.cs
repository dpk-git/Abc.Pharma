﻿namespace Abc.Pharma.Shared
{
    public class WebApiResult<T>
    {

        public WebApiResult(T response)
        {
            Response = response;
        }

        public WebApiResult(string error)
        {
            Error = error;
        }
        public T Response { get; set; }
        public string Error { get; set; }
        public bool HasError { get { return !string.IsNullOrEmpty(Error); } }
    }
}
