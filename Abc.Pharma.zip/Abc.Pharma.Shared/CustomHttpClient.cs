﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Abc.Pharma.Shared
{
    public static class CustomHttpClient
    {
        public static async Task<WebApiResult<T>> GetAsync<T>(Uri url)
        {
            try
            {
                string body;
                using (HttpClient client = new HttpClient())
                {
                    var response = await client.GetAsync(url);
                    body = await response.Content.ReadAsStringAsync();
                    response.EnsureSuccessStatusCode();
                }
                return new WebApiResult<T>(JsonConvert.DeserializeObject<T>(body));

            }
            catch (Exception)
            {
                return new WebApiResult<T>("Service error, try after sometime");
            }
        }

        public static async Task<WebApiResult<T>> PostAsync<T>(Uri url, object body)
        {
            string requestBody = JsonConvert.SerializeObject(body);
            try
            {
                string responseBody;
                using (HttpClient client = new HttpClient())
                {
                    using (StringContent content = new StringContent(requestBody, Encoding.UTF8, "application/json"))
                    {
                        var response = await client.PostAsync(url, content);
                        responseBody = await response.Content.ReadAsStringAsync();
                        response.EnsureSuccessStatusCode();
                    }

                }
                return new WebApiResult<T>(JsonConvert.DeserializeObject<T>(responseBody));

            }
            catch (Exception)
            {
                return new WebApiResult<T>("Service error, try after sometime");
            }
        }
    }
}
