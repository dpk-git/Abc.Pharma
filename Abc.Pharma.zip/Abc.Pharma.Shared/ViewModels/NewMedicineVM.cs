﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Abc.Pharma.Shared.ViewModels
{
    public class NewMedicineVM
    {
        [Required(ErrorMessage = "*")]
        [MaxLength(30, ErrorMessage = "Name should be 100 characters only")]
        public string Name { get; set; }


        [Required(ErrorMessage = "*")]
        [MaxLength(30, ErrorMessage = "Brand should be 30 characters only")]
        public string Brand { get; set; }


        [Required(ErrorMessage = "*")]
        [Range(1, 10000000)]
        public Decimal Price { get; set; }


        [Required(ErrorMessage = "*")]
        [Range(1, 10000)]
        public int Quantity { get; set; }


        [Required(ErrorMessage = "*")]
        //[DisplayFormat(DataFormatString ="{0: {dd/MM/yyyy}}")]
        public string ExpiryDate { get; set; }


        [MaxLength(500, ErrorMessage = "Brand should be 500 characters only")]
        public string Notes { get; set; }
    }
}
