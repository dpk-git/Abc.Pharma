﻿using Abc.Pharma.Repository;
using Abc.Pharma.Shared;
using Abc.Pharma.Shared.Entities;
using Abc.Pharma.Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;

namespace Abc.Pharma.WebApi.Controllers
{
    /// <summary>
    /// Medicine of dpk
    /// </summary>
    [RoutePrefix("api")]
    public class MedicineController : ApiController
    {
        IMedicineRepository _repo;
        public MedicineController(IMedicineRepository repo)
        {
            _repo = repo;

        }
        /// <summary>
        /// Get list of medicines
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("Medicines")]
        [ResponseType(typeof(IEnumerable<Medicine>))]
        public IHttpActionResult Get()
        {
            var medicines = _repo.GetMedicines() ?? new List<Medicine>();
            return Ok(medicines);
        }

        [HttpGet]
        [Route("Medicines/{id}")]
        [ResponseType(typeof(IEnumerable<Medicine>))]
        public IHttpActionResult Get(string id)
        {
            var medicines = _repo.GetMedicines(id);
            return Ok(medicines);
        }

        [HttpPost]
        [Route("Medicines")]
        [ResponseType(typeof(bool))]
        public IHttpActionResult Post(NewMedicineVM newMedicine)
        {
            if (ModelState.IsValid && newMedicine != null)
            {
                if (_repo.NameExists(newMedicine.Name))
                {
                    return BadRequest("A medicine with same name already exists");
                }

                Medicine medicine = new Medicine
                {
                    Id = Guid.NewGuid().ToString(),
                    Brand = newMedicine.Brand,
                    ExpiryDate = DateTime.Parse(newMedicine.ExpiryDate),
                    Name = newMedicine.Name,
                    Notes = newMedicine.Notes,
                    Price = newMedicine.Price,
                    Quantity = newMedicine.Quantity
                };
                _repo.AddMedicine(medicine);
                return Ok(true);
            }
            else
            {
                return BadRequest("The request is invalid");
            }
        }

        [HttpPost]
        [Route("Medicines/{id}")]
        [ResponseType(typeof(bool))]
        public IHttpActionResult Post(string id, NewMedicineVM newMedicine)
        {
            if (ModelState.IsValid && newMedicine != null)
            {
                var medicine = _repo.GetMedicines(id);
                if (medicine == null)
                {
                    return BadRequest("Medicine not found");
                }

                medicine.Brand = newMedicine.Brand;
                medicine.ExpiryDate = DateTime.Parse(newMedicine.ExpiryDate);
                medicine.Notes = newMedicine.Notes;
                medicine.Price = newMedicine.Price;
                medicine.Quantity = newMedicine.Quantity;
                _repo.Updatemedicine(medicine);
                return Ok(true);
            }
            else
            {
                return BadRequest("The request is invalid");
            }
        }


        public sealed class Singleton
        {
            private Singleton()
            {
            }

            public static Singleton Instance { get { return Nested.instance; } }

            private class Nested
            {
                // Explicit static constructor to tell C# compiler
                // not to mark type as beforefieldinit
                static Nested()
                {
                }

                internal static readonly Singleton instance = new Singleton();
            }
        }
    }
}
