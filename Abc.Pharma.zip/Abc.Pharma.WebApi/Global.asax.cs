﻿using Abc.Pharma.Repository;
using Swashbuckle.Application;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Routing;

namespace Abc.Pharma.WebApi
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);
            AutofacConfig.Configure(GlobalConfiguration.Configuration);
            Database.SetInitializer<MedicineContext>(new DropCreateDatabaseIfModelChanges<MedicineContext>());
            //GlobalConfiguration.Configuration
            //                        .EnableSwagger(c => c.SingleApiVersion("api/v1", "A title for your API"))
            //                        .EnableSwaggerUi();

        }
    }
}
