﻿using Abc.Pharma.Repository;
using Autofac;
using Autofac.Integration.WebApi;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Http;

namespace Abc.Pharma.WebApi
{
    internal static class AutofacConfig
    {
        internal static void Configure(HttpConfiguration config)
        {
            var builder = new ContainerBuilder();
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());

            builder.RegisterType<MedicineRepository>().As<IMedicineRepository>();
            builder.RegisterType<MedicineContext>().As<MedicineContext>();

            var container = builder.Build();
            config.DependencyResolver = new AutofacWebApiDependencyResolver(container);
        }
    }
}